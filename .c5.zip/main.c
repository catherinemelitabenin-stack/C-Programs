#include<stdio.h>
int main()
{
    int age,height;
    age=18;
    height=165;
    printf(" my age is %d\n",age);
    printf(" my height is %d",height);
    return 0;
}