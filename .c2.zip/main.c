#include<stdio.h>
int main()
{
    int age,height;
    printf("enter your age:");
    scanf("%d",&age);
    printf("enter your height:");
    scanf("%d",&height);
    
    printf("your age is : %d\n",age);
    printf("your height is : %d",height);
    return 0;
}