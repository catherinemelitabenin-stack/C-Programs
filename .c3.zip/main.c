#include<stdio.h>
int main()
{
    int a ,b,c,d,e,f;
    a=2;
    b=3;
    c=a+b;
    d=a-b;
    e=a*b;
    f=a/b;
    printf("the sum is %d\n",c);
    printf("the diff is %d\n",d);
    printf("the multi is %d\n",e);
    printf("the div is %d\n",f);
    return 0;
}
