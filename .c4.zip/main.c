#include<stdio.h>
int  main()
{
    char name;
    float height;
    int age;
    name = 'c';
    height=165;
    age = 18;
    printf("my name is %c\n" ,name);
    printf("my height is %f\n",height);
    printf("my age is %d\n",age);
    return 0;
    
}