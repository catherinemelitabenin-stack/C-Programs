#include<stdio.h>
int main()
{
    int a ,b,c;
    a=3;
    b=8;
    c=a+b;
    printf("c=a+b is %d\n",c);
    return 0;
}